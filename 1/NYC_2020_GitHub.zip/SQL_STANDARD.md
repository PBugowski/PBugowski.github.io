# Wzorzec wykonania i dokumentowania SQL

## Status i przeznaczenie

**Projekt referencyjny: NYC Road Accidents 2020, autor: Paweł Bugowski.**

Ten dokument zapisuje standard przyjęty na podstawie siedmiu oryginalnych skryptów SQL dostarczonych przez autora. Skrypty mają być punktem odniesienia przy czyszczeniu i refaktoryzacji kolejnych projektów: oczekiwany jest podobny poziom szczegółowości komentarzy, przejrzystości etapów i wyjaśnienia zastosowania danych w raporcie.

Oryginalne pliki pozostają niezmienione. Wzorcem jest ich sposób organizacji i dokumentowania. Poprawność SQL, zgodność komentarzy z kodem oraz zachowanie znaczenia danych trzeba weryfikować niezależnie dla każdego projektu.

Dokument jest przenośnym zapisem preferencji. Przy pracy w nowej rozmowie można dołączyć go wraz ze skryptami wymagającymi refaktoryzacji.

## Oryginalne materiały referencyjne

| Skrypt | Element wzorcowy |
| --- | --- |
| `1. Database & Table.sql` | Wprowadzenie do celu bazy, opis przechowywanych informacji i jawne typy danych |
| `2. Import of data.sql` | Wyjaśnienie importu, formatu CSV, zmiennych pośrednich i konwersji |
| `3.1. Normalization of data.sql` | Opis reguł standaryzacji, zakresu kolumn i znaczenia kategorii |
| `3.2. Multipolygons.sql` | Wyjaśnienie przetwarzania przestrzennego, układu współrzędnych i warunków aktualizacji |
| `4.1. Creation of reporting views.sql` | Dokumentacja celu każdego widoku, definicji wskaźników i powiązania z wizualizacjami |
| `4.2. Creation of dimension views.sql` | Oddzielenie wymiarów i wyjaśnienie ich roli w filtrowaniu oraz analizie czasu |
| `4.3. Creation of bridges.sql` | Opis mostków, zakresu danych i zastosowania do filtrowania po pojazdach |

## Zasady, które należy zachować

### 1. Numerowane etapy i logiczny porządek

Podziel projekt zgodnie z przepływem danych: utworzenie struktur, import, czyszczenie, wzbogacenie, widoki raportowe, wymiary i mostki. Stosuj nazwy plików podobne do referencji, np. `1. Database & Table.sql`, `2. Import of data.sql`, `3.1. Normalization of data.sql`.

Liczba etapów ma odpowiadać projektowi. Nie dodawaj geometrii, wymiarów ani mostków, jeśli nie mają uzasadnienia w danych. Istniejące nazwy obiektów używane przez raport zachowuj, o ile zadanie nie obejmuje ich zmiany.

### 2. Komentarze techniczne po angielsku

Domyślnym językiem komentarzy wewnątrz SQL jest **angielski**, zgodnie z projektem referencyjnym. Stosuj konkretne sformułowania wyjaśniające działanie, np. `Creates`, `Imports`, `Converts`, `Assigns`, `Excludes`, `Calculates`.

Komentarze powinny opisywać zarówno operację, jak i jej cel analityczny. Przy widokach wyjaśniaj, jakie pola udostępniają, do jakich miar lub wizualizacji służą i co oznacza pojedynczy wiersz.

### 3. Rozbudowany nagłówek pliku

Każdy skrypt rozpoczynaj od numeru etapu, tytułu i separatora. Poniżej opisz:

- cel etapu;
- obiekty wejściowe i wynikowe;
- najważniejsze przekształcenia;
- reguły dotyczące braków, wykluczeń i wartości domyślnych;
- zastosowanie w dalszej analizie lub raporcie;
- zależności od wcześniejszych etapów, jeżeli są istotne.

W przypadku prostego DDL wystarczy krótki opis. Przy rozbudowanych widokach i regułach przekształceń zachowaj poziom wyjaśnienia porównywalny ze skryptami NYC.

### 4. Sekcje dla odrębnych obiektów i operacji

W jednym pliku oddzielaj logiczne części nagłówkami i separatorami. Przed utworzeniem widoku lub wykonaniem istotnej aktualizacji dodaj komentarz wyjaśniający jej rezultat.

Komentarze na końcu wiersza wykorzystuj do objaśnienia nieoczywistych warunków, funkcji i parametrów. Nie przesuwaj ich bardzo daleko w prawo ciągiem tabulatorów. Opis wymagający kilku zdań umieść nad kodem.

### 5. Czytelne formatowanie

- Słowa kluczowe SQL i funkcje zapisuj wielkimi literami.
- Stosuj spójne wcięcia; przy nowej refaktoryzacji domyślnie cztery spacje.
- Rozbudowane listy kolumn zapisuj po jednej kolumnie w wierszu.
- W `CASE` umieszczaj kolejne warunki w oddzielnych wierszach.
- Oddzielaj `SELECT`, `FROM`, `JOIN`, `WHERE`, `GROUP BY` i `ORDER BY`.
- Kończ instrukcje średnikiem.
- Stosuj konsekwentną wielkość liter w nazwach tabel i widoków, uwzględniając środowisko wykonania.
- Długie dane referencyjne, np. WKT granic, zachowuj bez zmian wartości. Porządkowanie formatowania nie może zmienić geometrii.

Referencja używa nazw kolumn w stylu `COLLISION_ID`, prefiksów `DIM_` i `BRIDGE_` oraz sufiksu `_VW`. Zachowuj tę konwencję tam, gdzie pasuje do istniejącego projektu. Nie kopiuj oznaczeń `P1`–`P6`, jeżeli inny raport ma odmienną strukturę.

### 6. Jawne definicje i szczegółowość

Dokumentuj znaczenie miar i flag. Rozróżniaj liczbę rekordów, unikalnych zdarzeń, osób i pozycji pojazdów. Przy `UNION ALL`, mostkach i połączeniach opisz, kiedy identyfikator może się powtarzać i jak wpływa to na agregacje.

Przy procentach wskaż licznik, mianownik oraz poziom obliczenia. Przy czasie określ granice przedziałów, sposób sortowania i zakres dat. Przy danych przestrzennych podaj SRID, kolejność osi i warunki dopasowania.

### 7. Zachowanie znaczenia danych podczas refaktoryzacji

Czyszczenie kodu powinno zachowywać wyniki, reguły biznesowe oraz interfejs wykorzystywany przez raport. Nie zmieniaj bez wyjaśnienia kolejności warunków `CASE`, `UNION ALL` na `UNION`, sposobu obsługi `NULL`, filtrów, typów połączeń ani definicji wskaźników.

Jeśli wykryto błąd, opisz jego wpływ i odróżnij poprawkę działania od poprawki formatowania. Optymalizację lub zmianę modelu uzasadnij potrzebą projektu. Nie traktuj krótszego kodu jako celu ważniejszego od czytelności i poprawności.

### 8. Dokumentacja zgodna z wykonywanym kodem

Wzorcowy poziom komentarzy nie oznacza bezkrytycznego kopiowania opisów. Sprawdzaj, czy dokumentacja zgadza się z instrukcjami SQL. Jeżeli opis i kod są sprzeczne, ustal znaczenie operacji na podstawie danych, zadania i istniejących zależności, a rozbieżność jawnie odnotuj.

Przykłady wymagające uwagi w referencji NYC:

- nagłówek normalizacji wspomina o zachowaniu oryginalnej wartości przez `ELSE`, ale kod zwraca `OTHER`;
- komentarz dotyczący daty w imporcie wspomina `STR_TO_DATE`, choć funkcja jest wykonywana dla czasu;
- część odwołań używa `ACCIDENTS`, a tabela jest tworzona jako `accidents`;
- `COLLISION_ID` jest kluczem logicznym, lecz nie ma zadeklarowanego ograniczenia unikalności;
- widoki po `UNION ALL` mają inną szczegółowość niż podstawowa tabela zdarzeń;
- miesięczne udziały są obliczane przed filtrami Power BI i nie są addytywne;
- etap normalizacji jest aktualizacją danych, której ponowne wykonanie nie musi zachować wcześniejszego wyniku.

Oryginały zachowano jako referencję. Powyższe uwagi wyznaczają kontrole jakości dla przyszłych refaktoryzacji, a nie zmiany już zastosowane do plików NYC.

## Szablon nagłówka

Poniższy fragment jest szablonem dokumentacyjnym. Pola w nawiasach kwadratowych należy zastąpić informacjami o konkretnym projekcie.

```sql
-- [Step]. [Purpose of the Script]
-- -----------------------------------------------------------------------------------------------------------------
-- [Explains the analytical purpose of this processing step.]
--
-- Source objects:
--   - [source table or view]
--
-- The processing step:
--   - [describes the first transformation],
--   - [describes the treatment of missing or excluded values],
--   - [explains the resulting structure].
--
-- Output grain: [states what one output row represents].
-- The resulting [table/view] supports [analysis or report component].
-- -----------------------------------------------------------------------------------------------------------------
```

## Przykład stylu widoku

Przykład oparto na `P3_VW` z referencji. Służy jako wzór formatowania i opisu; nie jest dodatkowym etapem do uruchomienia w pipeline.

```sql
-- P3 Reporting View
-- -----------------------------------------------------------------------------------------------------------------
-- Creates an accident-level view containing geographic coordinates,
-- street names, collision identifiers, crash dates, and borough names.
--
-- Each row represents one accident from the source table.
-- The view supports road rankings, borough comparisons, and mapping.
-- Zero coordinates are retained here and must be excluded when mapping
-- individual accident locations.
-- -----------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE VIEW P3_VW AS
SELECT
    LATITUDE,
    LONGITUDE,
    ON_STREET_NAME,
    COLLISION_ID,
    CRASH_DATE,
    BOROUGH
FROM accidents;
```

## Oczekiwany rezultat kolejnej refaktoryzacji

Gotowy projekt powinien zawierać uporządkowane skrypty w kolejności wykonania, spójne komentarze i wyjaśnione reguły biznesowe. Podsumowanie zmian powinno wskazywać, co uporządkowano, jakie błędy poprawiono oraz jak zweryfikowano zachowanie wyników.

Weryfikację dobieraj do zakresu zmian. Przy modyfikacji reguł sprawdzaj odpowiednie liczności, sumy, unikalność kluczy i przypadki brzegowe. Gdy kod nie został uruchomiony na właściwym silniku, zaznacz to w podsumowaniu. Nie przedstawiaj przeglądu tekstu jako pełnego testu wykonania.

Przy zmianach wyłącznie redakcyjnych nie dodawaj zbędnych mechanizmów ani testów powielających kod. W kolejnych projektach celem jest poziom dokumentacji i przejrzystości zbliżony do NYC, dostosowany do rzeczywistej złożoności zadania.
